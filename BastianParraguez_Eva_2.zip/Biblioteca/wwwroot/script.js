﻿const apiBase = 'http://localhost:5042/api';

document.getElementById('form-libro').addEventListener('submit', async (e) => {
    e.preventDefault();

    const titulo = document.getElementById('titulo').value.trim();
    const autor = document.getElementById('autor').value.trim();
    const año = document.getElementById('anio').value.trim();
    const genero = document.getElementById('genero').value.trim();

    const soloLetras = /^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+$/;


    if (!titulo || !autor || !año || !genero) {
        mostrarMensaje("Por favor, completa todos los campos del libro.", "error");
        return;
    }

    if (!soloLetras.test(autor)) {
        mostrarMensaje("El campo 'Autor' solo puede contener letras.", "error");
        document.getElementById('autor').classList.add('error');
        return;
    } else {
        document.getElementById('autor').classList.remove('error');
    }

    if (!soloLetras.test(genero)) {
        mostrarMensaje("El campo 'Género' solo puede contener letras.", "error");
        return;
    }

    const libro = {
        titulo,
        autor,
        añoPublicacion: parseInt(año),
        genero
    };

    try {
        const res = await fetch(`${apiBase}/libros`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(libro)
        });

        if (res.ok) {
            mostrarMensaje("Libro agregado con éxito.");
            cargarLibros();
            e.target.reset();
        } else {
            const error = await res.text();
            mostrarMensaje("Error al agregar el libro: " + error, "error");
        }
    } catch (error) {
        mostrarMensaje("Error al agregar el libro: " + error.message, "error");
    }
});

async function cargarLibros() {
    try {
        const res = await fetch(`${apiBase}/libros`);
        if (!res.ok) throw new Error("Error al obtener libros");
        const libros = await res.json();

        const ul = document.getElementById('lista-libros');
        ul.innerHTML = '';

        libros.forEach(libro => {
            const li = document.createElement('li');
            li.textContent = `${libro.id}. ${libro.titulo} (${libro.autor}) - ${libro.estaPrestado ? 'PRESTADO' : 'DISPONIBLE'}`;
            if (!libro.estaPrestado) {
                const btn = document.createElement('button');
                btn.textContent = 'Eliminar';
                btn.onclick = async () => {
                    await fetch(`${apiBase}/libros/${libro.id}`, { method: 'DELETE' });
                    cargarLibros();
                };
                li.appendChild(btn);
            }
            ul.appendChild(li);
        });
    } catch (error) {
        mostrarMensaje("Error al cargar libros: " + error.message, "error");
    }
}

async function cargarUsuarios() {
    const ul = document.getElementById('lista-usuarios');
    ul.innerHTML = '';

    try {
        const res = await fetch(`${apiBase}/usuarios`);
        if (!res.ok) {
            mostrarMensaje('Error al cargar usuarios.', 'error');
            return;
        }
        const usuarios = await res.json();

        usuarios.forEach(usuario => {
            const li = document.createElement('li');
            li.textContent = `${usuario.id} - ${usuario.nombre}`;
            ul.appendChild(li);
        });
    } catch (error) {
        mostrarMensaje('Error al cargar usuarios: ' + error.message, 'error');
    }
}

document.getElementById('form-usuario').addEventListener('submit', async (e) => {
    e.preventDefault();

    const nombre = document.getElementById('nombreUsuario').value.trim();
    if (!nombre) {
        mostrarMensaje("Ingresa el nombre del usuario.", "error");
        return;
    }

    try {
        const res = await fetch(`${apiBase}/usuarios`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre })
        });

        if (res.ok) {
            mostrarMensaje("Usuario registrado.");
            cargarUsuarios();
            e.target.reset();
        } else {
            const error = await res.text();
            mostrarMensaje("Error al registrar usuario: " + error, "error");
        }
    } catch (error) {
        mostrarMensaje("Error al registrar usuario: " + error.message, "error");
    }
});

document.getElementById('form-prestamo').addEventListener('submit', async (e) => {
    e.preventDefault();

    const usuarioId = parseInt(document.getElementById('usuarioPrestamo').value);
    const libroId = parseInt(document.getElementById('libroPrestamo').value);

    if (!usuarioId || !libroId) {
        mostrarMensaje("Completa los ID de usuario y libro.", "error");
        return;
    }

    try {
        const res = await fetch(`${apiBase}/prestamos`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usuarioId, libroId })
        });

        if (res.ok) {
            mostrarMensaje("Préstamo registrado.");
            cargarLibros();
            cargarPrestamosActivos();
            e.target.reset();
        } else {
            const error = await res.text();
            mostrarMensaje("Error: " + error, "error");
        }
    } catch (error) {
        mostrarMensaje("Error al registrar préstamo: " + error.message, "error");
    }
});

document.getElementById('form-devolucion').addEventListener('submit', async (e) => {
    e.preventDefault();

    const id = parseInt(document.getElementById('prestamoId').value);
    if (!id) {
        mostrarMensaje("Ingresa el ID del préstamo.", "error");
        return;
    }

    const res = await fetch(`${apiBase}/prestamos/devoluciones`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prestamoId: id })
    });

    if (res.ok) {
        mostrarMensaje("Devolución registrada.");
        cargarLibros();
        cargarPrestamosActivos();
        e.target.reset();
    } else {
        const error = await res.text();
        console.error('Error en devolución:', error);
        mostrarMensaje("Error: " + error, "error");
    }
});


function mostrarMensaje(texto, tipo = "ok") {
    const mensaje = document.getElementById('mensaje');
    mensaje.textContent = texto;
    mensaje.className = `mensaje ${tipo}`;
    mensaje.style.display = 'block';
    mensaje.style.opacity = '1';

    setTimeout(() => {
        mensaje.style.opacity = '0';
        setTimeout(() => mensaje.style.display = 'none', 300);
    }, 3000);
}

async function cargarPrestamosActivos() {
    const ul = document.getElementById('lista-prestamos-activos');
    ul.innerHTML = '';

    try {
        const res = await fetch(`${apiBase}/prestamos/activos`);
        if (!res.ok) {
            mostrarMensaje('Error al cargar préstamos activos.', 'error');
            return;
        }

        const prestamos = await res.json();

        prestamos.forEach(prestamo => {
            const li = document.createElement('li');
            li.textContent = `Usuario: ${prestamo.usuarioNombre} - Préstamo ID: ${prestamo.id}`;
            ul.appendChild(li);
        });
    } catch (error) {
        mostrarMensaje('Error al cargar préstamos activos: ' + error.message, 'error');
    }
}

cargarLibros();
cargarUsuarios();
cargarPrestamosActivos();

