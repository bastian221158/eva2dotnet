namespace BibliotecaApi.Models
{
    public class DevolucionRequest
    {
        public int PrestamoId { get; set; }
    }
}
