﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BibliotecaApi.Models;
using BibliotecaApi.Data;

namespace BibliotecaApi.Controllers
{
    [ApiController]
    [Route("api/prestamos")]
    public class PrestamosController : ControllerBase
    {
        private readonly BibliotecaContext _context;

        public PrestamosController(BibliotecaContext context)
        {
            _context = context;
        }

        [HttpPost]
public async Task<IActionResult> CrearPrestamo([FromBody] Prestamo prestamo)
{
    var libro = await _context.Libros.FindAsync(prestamo.LibroId);
    if (libro == null)
        return NotFound("Libro no encontrado.");

    if (libro.EstaPrestado)
        return BadRequest("El libro ya está prestado.");

    var usuario = await _context.Usuarios.FindAsync(prestamo.UsuarioId);
    if (usuario == null)
        return NotFound("Usuario no encontrado.");

    prestamo.FechaPrestamo = DateTime.Now;
    prestamo.FechaDevolucion = null;

    libro.EstaPrestado = true;

    _context.Prestamos.Add(prestamo);
    await _context.SaveChangesAsync();

    return Ok(new {
        prestamo.Id,
        prestamo.UsuarioId,
        prestamo.LibroId,
        prestamo.FechaPrestamo,
        prestamo.FechaDevolucion
    });
}


        [HttpPost("devoluciones")]
        public async Task<IActionResult> RegistrarDevolucion([FromBody] DevolucionRequest request)
        {
            var prestamo = await _context.Prestamos
                .Include(p => p.Libro)
                .FirstOrDefaultAsync(p => p.Id == request.PrestamoId);

            if (prestamo == null)
                return NotFound("Préstamo no encontrado.");

            if (prestamo.FechaDevolucion != null)
                return BadRequest("Este libro ya fue devuelto.");

            prestamo.FechaDevolucion = DateTime.Now;
            prestamo.Libro!.EstaPrestado = false;

            await _context.SaveChangesAsync();

            return Ok(prestamo);
        }


        [HttpGet("activos")]
        public async Task<ActionResult<IEnumerable<object>>> GetPrestamosActivos()
        {
            var prestamosActivos = await _context.Prestamos
                .Where(p => p.FechaDevolucion == null)
                .Include(p => p.Usuario)
                .Include(p => p.Libro)
                .Select(p => new {
                    p.Id,
                    UsuarioNombre = p.Usuario!.Nombre,
                    LibroTitulo = p.Libro!.Titulo,
                    p.FechaPrestamo
                })
                .ToListAsync();

            return prestamosActivos;
        }
    }
}
