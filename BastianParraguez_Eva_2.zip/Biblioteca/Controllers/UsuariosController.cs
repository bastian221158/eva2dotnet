﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BibliotecaApi.Models;
using BibliotecaApi.Data;

namespace BibliotecaApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuariosController : ControllerBase
    {
        private readonly BibliotecaContext _context;

        public UsuariosController(BibliotecaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Usuario>>> GetUsuarios()
        {
            return await _context.Usuarios.ToListAsync();
        }

        [HttpPost]
        public async Task<ActionResult<Usuario>> CrearUsuario(Usuario usuario)
        {
            _context.Usuarios.Add(usuario);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetUsuario), new { id = usuario.Id }, usuario);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Usuario>> GetUsuario(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario == null)
                return NotFound();
            return usuario;
        }

        [HttpGet("{id}/prestamos")]
        public async Task<ActionResult<IEnumerable<Prestamo>>> GetPrestamosDelUsuario(int id)
        {
            var usuario = await _context.Usuarios
                .Include(u => u.Prestamos!)
                .ThenInclude(p => p.Libro)
                .FirstOrDefaultAsync(u => u.Id == id);

            if (usuario == null)
                return NotFound();

            return usuario.Prestamos!.ToList();
        }
        [HttpDelete("usuarios/{id}")]
        public async Task<IActionResult> EliminarUsuario(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario == null)
                return NotFound("Usuario no encontrado.");

            bool tienePrestamosActivos = await _context.Prestamos
                .AnyAsync(p => p.UsuarioId == id && p.FechaDevolucion == null);

            if (tienePrestamosActivos)
                return BadRequest("No se puede eliminar el usuario porque tiene préstamos activos.");

            _context.Usuarios.Remove(usuario);
            await _context.SaveChangesAsync();

            return Ok("Usuario eliminado.");
        }

        [HttpGet("usuarios")]
        public async Task<ActionResult<IEnumerable<object>>> ObtenerUsuarios()
        {
            var usuarios = await _context.Usuarios
                .Select(u => new {
                    u.Id,
                    u.Nombre,
                    TienePrestamoActivo = _context.Prestamos
                        .Any(p => p.UsuarioId == u.Id && p.FechaDevolucion == null)
                })
                .ToListAsync();

            return Ok(usuarios);
        }
    }
}
