﻿namespace BibliotecaApi.Models
{
    public class Libro
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public int AñoPublicacion { get; set; }
        public string Genero { get; set; }
        public bool EstaPrestado { get; set; } = false;
    }
}
